package test;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.module.jsv.JsonSchemaValidator;
import java.util.concurrent.TimeUnit;
import static io.restassured.RestAssured.given;

public class GetApiTest {

    @BeforeClass
    public void setup() {
        // Base URI
        RestAssured.baseURI = "https://reqres.in/api";
    }

    @Test(priority = 1)
    public void validateResponseCode() {
        // Send GET request and validate the response code
        Response response = given()
                .when()
                .get("/users?page=2")
                .then()
                .extract()
                .response();

        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200, "Expected status code is 200");
    }
    
    @Test(priority = 2)
    public void validateResponseSchema() {
        // Validate the response JSON schema
        given()
                .when()
                .get("/users?page=2")
                .then()
                .assertThat()
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("user-schema.json"))
                .log().all();
    }

    @Test(priority = 3)
    public void validateResponseData() {
        // Validate specific data in the response
        Response response = given()
                .when()
                .get("/users?page=2")
                .then()
                .extract()
                .response();

        // Validate the first user's email
        String firstUserEmail = response.jsonPath().getString("data[0].email");
        Assert.assertTrue(firstUserEmail.contains("reqres.in"), "First user's email does not match");
    }

    @Test(priority = 4)
    public void validateResponseTime() {
        // Validate that the response time is within acceptable limits
        Response response = given()
                .when()
                .get("/users?page=2")
                .then()
                .extract()
                .response();

        long responseTimeInMs = response.getTimeIn(TimeUnit.MILLISECONDS);
        // Assert response time is less than 2000 ms
        Assert.assertTrue(responseTimeInMs < 2000, "Response time is too high");
    }
}
